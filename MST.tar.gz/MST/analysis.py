
# coding: utf-8

# In[3]:

import glob
import pickle
import numpy as np
from numpy import arctan, arctan2, cos, rad2deg, deg2rad
import matplotlib.pyplot as plt
from astropy.coordinates import SkyCoord, Galactic
from astropy.coordinates import match_coordinates_sky
from astropy import units as u
from astropy import constants as const
from astropy.wcs import WCS

from astropy.table import Table, Column
from scipy.stats.stats import pearsonr, spearmanr
from astropy.modeling import models, fitting

from scipy.spatial.distance import pdist, squareform
from scipy.stats import describe
from pylab import *
from astropy.io import ascii

import os
from astropy.io import fits
import pyregion
ion()



l1, l2 = 0, 360


import numpy as np
import matplotlib.pyplot as plt
from astropy.coordinates import SkyCoord
from astropy import units as u
from astropy.coordinates import match_coordinates_sky
fp1=open('table2.dat')
fp2=open('table5.dat')
fp3=open('table1.dat')
l = []
b = []
v = []
radius = []
flux = []
distance = []
Rgcc = []
Tdust = []
logLbol = []
logMclump = []
logNH2 = []

major = []
minor = []
PA = []
eff_R = []

table2 = []
table5 = []

i = 0
lines2 = fp2.readlines()
lines3 = fp3.readlines()

for linea1 in fp1.readlines():
    linea1 = linea1.strip().split()[:]
    linea2 = lines2[i].strip().split()[:]
    linea3 = lines3[i].strip().split()[:]
    i += 1
    
    try:
        v.append(float(linea1[1]))
    except ValueError:
        continue
    
    if linea2[5] == '---':
        distance.append(np.nan)
    else:
        distance.append(float(linea2[5]))
    if linea2[7] == '---':
        radius.append(np.nan)
    else:
        radius.append(float(linea2[7]))
    if linea2[3] == '---':
        flux.append(-1)
    else:
        flux.append(float(linea2[3]))
    if linea2[6] == '---':
        Rgcc.append(np.median(Rgcc))
    else:
        Rgcc.append(float(linea2[6]))
    if linea2[8] == '---':
        Tdust.append(np.median(Tdust))
    else:
        Tdust.append(float(linea2[8]))
    if linea2[9] == '---':
        logLbol.append(np.median(logLbol))
    else:
        logLbol.append(float(linea2[9]))
    if linea2[10] == '---':
        logMclump.append(np.nan)
    else:
        logMclump.append(float(linea2[10]))
    if linea2[11] == '---':
        logNH2.append(np.median(logNH2))
    else:
        logNH2.append(float(linea2[11]))
    
    major.append(float(linea3[5]))
    minor.append(float(linea3[6]))
    PA.append(float(linea3[7]))
    eff_R.append(float(linea3[8]))
    
    l.append(float(linea1[0][4:11]))
    b.append(float(linea1[0][11:18])) 
    
    table2.append(linea1)
    table5.append(linea2)
    
cnum = np.arange(len(l))  
l = np.array(l)
b = np.array(b)
v = np.array(v)
distance = np.array(distance)
radius = np.array(radius)
flux = np.array(flux)
Rgcc = np.array(Rgcc)
Tdust = np.array(Tdust)
logLbol = np.array(logLbol)
logMclump = np.array(logMclump)
logNH2 = np.array(logNH2)

major = np.array(major)/3600
minor = np.array(minor)/3600
PA = np.array(PA)
eff_R = np.array(eff_R)


table2 = np.array(table2)
table5 = np.array(table5)


mv = np.ma.masked_where(v<999, v).mask
# mask on l
#l1,l2 = 25,26
ml = np.ma.masked_where( (l>l1)&(l<l2), l).mask
# form the final mask
mask = ml*mv
# apply mask to arrays
l = l[mask]
b = b[mask]
v = v[mask]
cnum = cnum[mask]
distance = distance[mask]
radius = radius[mask]
flux = flux[mask]
Rgcc = Rgcc[mask]
Tdust = Tdust[mask]
logLbol = logLbol[mask]
logMclump = logMclump[mask]
logNH2 = logNH2[mask]
major = major[mask]
minor = minor[mask]
PA = PA[mask]
eff_R = eff_R[mask]
l[l>180] -= 360

plt.scatter(l,b, s=50, c=v, cmap='cubehelix', alpha=.8) #vmax=150, 
plt.colorbar(label='km/s')
#plt.xlim(l2, l1)
plt.show()

# form 3d and 2d arrays, to be used to generate MST
lbv = np.zeros( (len(l), 3) )
lbv[:,0] = l
lbv[:,1] = b
lbv[:,2] = v
lb = lbv[:,0:2]


# filtered catalog
a_origin = {}
a_origin['cnum'] = cnum.copy()
a_origin['l'] = l.copy()
a_origin['b'] = b.copy()
a_origin['v'] = v.copy()
a_origin['radius'] = radius.copy()
a_origin['flux'] = flux.copy()
a_origin['distance'] = distance.copy()
a_origin['Rgcc'] = Rgcc.copy()
a_origin['Tdust'] = Tdust.copy()
a_origin['logLbol'] = logLbol.copy()
a_origin['logMclump'] = logMclump.copy()
a_origin['logNH2'] = logNH2.copy()

# results from MST
with open("branch_list.dat", 'rb') as f:
    branch_list = pickle.load(f)
    
branch_list = np.array(branch_list)


# per filament
t = Table(names=('No', 'l_wt', 'b_wt', 
    'l_min', 'l_max', 'b_min', 'b_max',
    'v_wt', 
    'dkpc', 'n_clumps', 'total_flux', 
    'fl_len_deg','fl_length','fl_len_end','fl_len_wt', 'mean_edge', 'std_edge',
    'velo_grad', 'CVD',
    'T_min','T_max','T_mean',
    'mass', 'mass_mean', 'mass_std',
    'M_L','colH2', 'volH2', 'aspect',
    'Linearity', 'Rgc', 'z', 'theta'),
         dtype=('i8','f8','f8',
                'f8','f8','f8','f8',
                'f8',
                'f8','i8','f8',
               'f8','f8','f8','f8','f8','f8',
               'f8','f8',
               'f8','f8','f8',
               'f8','f8','f8',
               'f8','f8','f8','f8',
               'f8','f8','f8','f8'))
# output format
t['No'].format = 'n'
t['l_wt'].format = '.2f'
t['b_wt'].format = '.2f'

t['l_min'].format = '.2f'
t['l_max'].format = '.2f'
t['b_min'].format = '.2f'
t['b_max'].format = '.2f'

t['v_wt'].format = '.1f'

t['dkpc'].format = '.1f'

#t['dist_type'].format = 'n'
t['n_clumps'].format = 'n'
t['total_flux'].format = '.1f'

t['fl_len_deg'].format = '.2f'
t['fl_length'].format = '.1f'
t['fl_len_end'].format = '.1f'
t['fl_len_wt'].format = '.1f'
t['mean_edge'].format = '.1f'
t['std_edge'].format = '.1f'

t['velo_grad'].format = '.2f'
t['CVD'].format = '.2f'

t['T_min'].format = '.1f'
t['T_max'].format = '.1f'
t['T_mean'].format = '.1f'

t['mass'].format = '.1f'
t['mass_mean'].format = '.1f'
t['mass_std'].format = '.1f'

t['M_L'].format = '.1f'
t['colH2'].format = '.1f'
t['volH2'].format = '.1f'
#t['sigV_NT'].format = '.1f'
t['aspect'].format = '.1f'

t['Linearity'].format = '.1f'
t['Rgc'].format = '.1f'
t['z'].format = '.1f'
t['theta'].format = '.1f'


t1 = t.copy()
t3 = t.copy()


#----------- get ready for mid Plane and z  ------------------------------------------------

exec(open("sgraframe.py").read())

#----------- begin  ------------------------------------------------
good_fl = 0
good_dist = 0
count_T = 0
count_Tupper = 0

region_extent = 2 # to extend region mask for mass calculation

i_fl = [] # idx of large filament
d_fl = [] # list of distance for the large filaments

i_cl_large = []
branch_cl = []


radius_deg = rad2deg(radius/distance/1000)

region_all = []
region_dense = []

cylinder_r = []


for ii,branch in enumerate(branch_list):
	# all clumps in this filament
    branch = np.array(branch)
    clump_index = np.unique(branch)
    branch_cl.append(clump_index)
    ci = np.array(clump_index)
    n_clumps = len(ci)
    print ("Filament #", ii+1)
        
    T_min = np.min(Tdust[ci])
    T_max = np.max(Tdust[ci])
    T_mean = np.mean(Tdust[ci])
    
    
    
    #----------- Flux, flux weighted l,b,v, CVD ------------------------------------------------
    
    # Flux weighted l,b,v
    total_flux = np.sum(flux[ci])
    flux_mean = np.mean(flux[ci])
    flux_std  = np.std(flux[ci])
    l_wt = np.sum( l[ci] * flux[ci] ) / total_flux
    b_wt = np.sum( b[ci] * flux[ci] ) / total_flux
    v_wt = np.sum( v[ci] * flux[ci] ) / total_flux
    
    
    CVD = np.std( v[ci])
    
    index_dnan = np.isnan(distance[ci])
    dkpc = np.nanmedian(distance[ci])
    distance[ci[index_dnan]] = dkpc 
    # give the fl distance to clumps without distance measurement
    
    #--------- modify radius ---------------
    index_rnan = np.isnan(radius[ci])
    radius[ci[index_rnan]] = 1000*distance[ci[index_rnan]]*np.deg2rad(19.2/3600)

    radius[ci]=radius[ci]*dkpc/distance[ci] #scale radius with distance

    
    index_rdnan = index_rnan + index_dnan
    radius_deg[ci[index_rdnan]] = rad2deg(radius[ci[index_rdnan]]/distance[ci[index_rdnan]]/1000)
    
    #----------- Make plot ------------------------------------------------
    
    edge_lengths = []
    v_grads = []
    for edge in branch:
        i, j = edge
        #plt.plot([l[i], l[j]], [v[i], v[j]], c='k', lw=3, alpha=.6)
        plt.plot([l[i], l[j]], [b[i], b[j]], c='k', lw=3, alpha=.8)

        # edge length
        p1 = SkyCoord(l[i], b[i], unit=u.deg, frame='galactic')
        p2 = SkyCoord(l[j], b[j], unit=u.deg, frame='galactic')
        sep = p1.separation(p2)
        edge_lengths.append(sep.deg)

        # velocity gradient on each edge
        sep_pc = sep.deg * 3600.0 * dkpc*1e3/206265. # deg>arcsec>pc
        vg = abs(v[i]-v[j]) / sep_pc # km/s / pc
        v_grads.append(vg)

        
    
    
    #----------- Length, mass, velo gradient, z, Rgc, theta ------------------------------------------------
    
    # length, deg and pc
    fl_len_deg = np.sum(edge_lengths) # filament length in deg, below go to pc
    edge_lengths = np.array(edge_lengths) * 3600.0 * dkpc*1e3/206265. # deg>arcsec>pc
    fl_length = np.sum(edge_lengths)
    mean_edge = np.mean(edge_lengths)
    std_edge  = np.std(edge_lengths)

    # velocity gradient: mean of edges
    velo_grad = np.mean(v_grads)
    
    # <length> farest points
    P = np.zeros( (len(l[ci]), 2) )
    P[:,0] = l[ci]
    P[:,1] = b[ci]
    mean_len = np.max(pdist(P))
    mean_len *= 3600.0 * dkpc*1e3/206265    
    
    # mass 
    
    # mass here is the sum of clump mass in this filament, it will be replaced later
    # if there is no mass in catalogue, calculate it
    index_Mnan = np.isnan(logMclump[ci])    
    freq0 = const.c/(870*u.um)
    R_g2d=100
    kai_v=1.85*(u.cm)**2/u.g
    B_vT = 2*const.h*freq0**3/(const.c)**2/(np.exp(const.h*freq0/const.k_B/(Tdust[ci][index_Mnan]*u.K))-1)
    logMclump[ci[index_Mnan]] = np.log10    ((((distance[ci][index_Mnan]*u.kpc)**2*flux[ci][index_Mnan]*u.Jansky*R_g2d/B_vT/kai_v/u.M_sun).decompose()).value)
    #-
    logMclump[ci] = logMclump[ci]-np.log10(distance[ci]**2) + np.log10(dkpc**2) #scale mass with distance
    Mfl = 10 ** logMclump[ci]
    mass = np.sum(Mfl)
    mass_mean = np.mean(Mfl)
    mass_std = np.std(Mfl)
    # linear mass density Msun/pc
    M_L = mass/fl_length
    



    # Distance to GC
    Rgc = np.median(Rgcc[ci] * dkpc/distance[ci]) #scaled with 1/d
    
    l0,l1 = l[ci].min(), l[ci].max()
    b0,b1 = b[ci].min(), b[ci].max()

    
    # list of clump radii in this filament
    list_radii=radius[ci].copy()

    
    # list of clump mass in unit of number of H2 molecule
    Mfl_H2 = Mfl*1.9891e33/(2*1.6733e-24)
    #
    # list of clump radius in cm
    #Rcm = list_radii * dkpc *1e3 * 1.5e13 # arscec to cm
    Rcm = list_radii * 3.08567758e18 # pc to cm
    #
    # column density cm^-2
    list_colH2 = 10 ** logNH2[ci]
    # volumn density cm^-3
    list_volH2 = Mfl_H2 / (4./3. * 3.14159*Rcm*Rcm*Rcm)

    colH2 = np.nanmean(list_colH2)/1e22 #for clumps
    volH2 = np.nanmean(list_volH2)/1e3 #for clumps
    
    if len(list_radii) < 1:
        print (" ")
        print ("################################## ACHTUNG ****************#################")
        print (" ")
    
    
    
    # new column and volumn density calculation, for cylinder, not for clumps
    #
    # projected cylinder area, cm^2
    cylinder_area = 2*np.mean(Rcm) * fl_length*3.08567758e18 # pc to cm
    # cylinder volumn, cm^3
    cylinder_vol  = (3.14159*np.mean(Rcm)**2) * fl_length*3.08567758e18 # pc to cm
    #
    colH2 = np.sum(Mfl_H2)/cylinder_area/1e22
    volH2 = np.sum(Mfl_H2)/cylinder_vol/1e3       
    cylinder_r.append(np.nanmean(list_radii))
    distance[ci] = dkpc
    
    # find a clump in the "middle" of filament
    x = np.zeros( (len(l[ci]), 2) )
    x[:,0] = l[ci]
    x[:,1] = b[ci]
    #dl = l[ci].max() - l[ci].min()
    #db = b[ci].max() - b[ci].min()
    l_std = l[ci].std()
    b_std = b[ci].std()
    if l_std>=b_std:  # for most filaments, l is more spread than b
        y = x[np.argsort(x[:, 0])] # sort by l
    else:
        y = x[np.argsort(x[:, 1])] # sort by b
    l_mid, b_mid = y[len(y)//2]

    #----------- Linearity (=shape), theta ------------------------------------------------
    l_std = l[ci].std()
    b_std = b[ci].std()
    
    coeff = spearmanr(l[ci], b[ci])[0]
    coeff_str = "{:.1f}".format(coeff)
    
    # fit a line for l,b to determin FL orientation angle
    line_init = models.Linear1D()
    fit_line = fitting.LinearLSQFitter()

    if l_std>=b_std:
        x,y = l[ci], b[ci]
        line = fit_line(line_init, x,y)
        plt.plot(x, line(x), 'r-', linewidth=3, alpha=0.9)
        slope = line.slope.value
        theta1 = arctan(slope)
        y_residual = y-line(x)
        shape = ( x/cos(theta1) ).std() / ( y_residual*cos(theta1) ).std()
        # reduced chi^2, 
        # https://en.wikipedia.org/wiki/Goodness_of_fit#Example
        chi2 = sum( (y-line(x))**2 /b_std**4 ) / (n_clumps -2.0)
        
        theta = rad2deg(theta1)
        fl_len_end = np.max(x*np.cos(theta1) + y*np.sin(theta1)) - np.min(x*np.cos(theta1) + y*np.sin(theta1))
        fl_len_wt = fl_len_end * (1+4/shape**2)**0.5
        
    else:
        y,x = l[ci], b[ci]
        line = fit_line(line_init, x,y)
        plt.plot(line(x), x, 'r-', linewidth=3, alpha=0.9)
        slope = line.slope.value
        theta = arctan(slope)        
        y_residual = y-line(x)
        shape = ( x/cos(theta) ).std() / ( y_residual*cos(theta) ).std()
        chi2 = sum( (y-line(x))**2 /l_std**4 ) / (n_clumps -2.0)
        
        theta1 = arctan(1./slope)
        theta = rad2deg(theta)
        fl_len_end = np.max(x*np.cos(theta1) + y*np.sin(theta1)) - np.min(x*np.cos(theta1) + y*np.sin(theta1))
        fl_len_wt = fl_len_end * (1+4/shape**2)**0.5
    fl_len_end = fl_len_end * 3600.0 * dkpc*1e3/206265.
    fl_len_wt = fl_len_wt * 3600.0 * dkpc*1e3/206265.

    chi2_str = "{:.2}".format(chi2)
    slope_str = "{:.2}".format(slope)
    shape_str = "{:.1f}".format(shape)
    theta_str = "{:.0f}".format(theta)
    
    # aspect ratio
    aspect = fl_len_wt / np.nanmedian(list_radii)
    
    # functions from sgraframe.py
    #
    # height to mid-plane, positive z means at the same side of Sun
    z = scale_height(l_wt, b_wt, dkpc) # pc
    #
    # correct filament orientation angle to mid-plane
    mp = full_midplane(distance=dkpc*u.kpc, bounds=[l_wt-0.5, l_wt+0.5], npix=2)
    dx = mp.l.deg[-1] - mp.l.deg[0]
    dy = mp.b.deg[-1] - mp.b.deg[0]
    theta_mp = rad2deg( arctan(dy/dx) )  # very small, <0.2 deg
    theta = theta - theta_mp  
    
    #----------- get mask ------------------------------------------------
    
    region = "galactic"
    for i in ci:
        region += ";circle(%f, %f, %f)"%(l[i], b[i], region_extent*2*major[i])

    for bi in branch:
        region += ";box(%f, %f, %f, %f, %f)"        %(np.mean(l[bi]), np.mean(b[bi]), np.sqrt((l[bi[0]]-l[bi[1]])**2+(b[bi[0]]-b[bi[1]])**2),          region_extent*2*np.min(2*major[bi]), -1*rad2deg(np.arctan((b[bi[0]]-b[bi[1]])/(l[bi[0]]-l[bi[1]]))))
    region += "# text={#%d L%.1f}\n"%(ii+1,shape)
    region_all.append(region)
    
    region = "galactic"
    for i in ci:
        region += ";circle(%f, %f, %f)"%(l[i], b[i], 2*major[i])
    region += "# text={#%d L%.1f}\n"%(ii+1,shape)
    region_dense.append(region)
    
    #----------- Annotate plot ------------------------------------------------
    
    extra_str = "{:.1f}".format(mean_len/fl_length)
    plt.scatter(l_wt, b_wt, s=300, alpha=.3, c='red')
    my_str = 'F'+str(ii+1)+','+shape_str+','+extra_str
    if shape>1.5:
        plt.annotate(my_str, xy=(l_mid, b_mid), fontsize=30)
        good_fl += 1
    else:
        plt.annotate(my_str, xy=(l_mid, b_mid), fontsize=30, color='b')
    
    
    
    
    
    #----------- Output tables ------------------------------------------------
    
    # new para to output:
    #sigV_NT, colH2/1e22, volH2/1e4, aspect, M/L
    
    # add row to table
    t.add_row([ii, l_wt, b_wt, l0,l1,b0,b1, v_wt, 
        dkpc, n_clumps, total_flux, 
        fl_len_deg, fl_length,fl_len_end,fl_len_wt, mean_edge, std_edge,
        velo_grad, CVD,
        T_min, T_max, T_mean, mass/1e3, mass_mean, mass_std,
        M_L, colH2, volH2, aspect,
        shape, Rgc, z, theta])

        
    # linear,large filaments
    if (shape>1.5) and (fl_length>9.9):
        t1.add_row([ii, l_wt, b_wt, l0,l1,b0,b1, v_wt, 
             dkpc, n_clumps, total_flux, 
             fl_len_deg, fl_length,fl_len_end,fl_len_wt, mean_edge, mean_len, #std_edge,
             velo_grad, CVD,
             T_min, T_max, T_mean, mass/1e3, mass_mean, mass_std,
             M_L, colH2, volH2, aspect,
             shape, Rgc, z, theta])
        i_fl.append(ii)
        d_fl.append(dkpc)
        i_cl_large.extend(ci)

    
    # linear, large, on midplane, orientation
    if (shape>1.5) and (fl_length>9.9) and (abs(z)<=20.) and (abs(theta)<=30.):
        t3.add_row([ii, l_wt, b_wt, l0,l1,b0,b1, v_wt, 
             dkpc, n_clumps, total_flux, 
             fl_len_deg, fl_length,fl_len_end,fl_len_wt, mean_edge, std_edge,
             velo_grad, CVD,
             T_min, T_max, T_mean, mass/1e3, mass_mean, mass_std,
             M_L, colH2, volH2, aspect,
             shape, Rgc, z, theta])

i_cl_large = np.array(i_cl_large)
i_cl_large = np.unique(i_cl_large)

fp = open("DGMR_ATDGMR_massfl.txt")
DGMR = []
ATDGMR = []
massfl = []
for linea in fp.readlines():
    DGMR.append(float(linea.split()[0]))
    ATDGMR.append(float(linea.split()[1]))
    massfl.append(float(linea.split()[2]))
DGMR = np.array(DGMR)
ATDGMR = np.array(ATDGMR)
massfl = np.array(massfl)

# give fl without mass from ATLASGAL clump and median ATDGMR, where ATDGMR is the ratio between total clump mass 
# of a filament and filament mass from Herschel Hi-GAL column density map
massfl[np.isnan(massfl)] = t['mass'][np.isnan(massfl)]*1000/np.nanmedian(t['mass']*1000/massfl)

# modify mass
mod_m = massfl/t['mass']/1000
t['mass'] = t['mass']*mod_m[t['No']]
t['M_L'] = t['M_L']*mod_m[t['No']]
t['colH2'] = t['colH2']*mod_m[t['No']]
t['volH2'] = t['volH2']*mod_m[t['No']]

t1['mass'] = t1['mass']*mod_m[t1['No']]
t1['M_L'] = t1['M_L']*mod_m[t1['No']]
t1['colH2'] = t1['colH2']*mod_m[t1['No']]
t1['volH2'] = t1['volH2']*mod_m[t1['No']]

t3['mass'] = t3['mass']*mod_m[t3['No']]
t3['M_L'] = t3['M_L']*mod_m[t3['No']]
t3['colH2'] = t3['colH2']*mod_m[t3['No']]
t3['volH2'] = t3['volH2']*mod_m[t3['No']]

#generate ds9 region file of filament boundary
f = open("region_all.reg",'w')
f.writelines('# Region file format: DS9 version 4.1\nglobal color=green dashlist=8 3 width=1 font="helvetica 10 normal roman" select=1 highlite=1 dash=0 fixed=0 edit=1 move=1 delete=1 include=1 source=1\n')
f.writelines(region_all)
f.close()
f = open("region_dense.reg",'w')
f.writelines('# Region file format: DS9 version 4.1\nglobal color=green dashlist=8 3 width=1 font="helvetica 10 normal roman" select=1 highlite=1 dash=0 fixed=0 edit=1 move=1 delete=1 include=1 source=1\n')
f.writelines(region_dense)
f.close()


# In[5]:

# Table out

t1a = t1.copy()

t1a.remove_columns(['No','l_min', 'l_max', 'b_min', 'b_max'])
t1a.remove_columns(['total_flux', 'mean_edge', 'std_edge', 'mass_mean', 'mass_std','T_mean'])

cc = Column(np.arange(1,len(t1['No'])+1), name='ID')
t1a.add_column(cc,0)

#add morphology
morph=[]
with open('morph.txt','r') as f:
    lines = f.readlines()
    for line in lines:
        if line!='\n':
            morph.append(line.strip())

aa = Column(morph, name='Morph')
t1a.add_column(aa)

# Add density type to t1a
import csv
density_type = []
with open('tab/t_densitytype.csv','r') as myFile:
    lines=csv.reader(myFile)
    for line in lines:
        density_type.append(line[-1])
density_type.pop(0)

for i in range(len(density_type)):
    if density_type[i] != 'full':
        DGMR[i] = -1
density_type = np.array(density_type)
bb = Column(DGMR[t1['No']], name='DGMR')
t1a.add_column(bb)
t1a['DGMR'].format = '.2f'

# Statistics - part 1/2


from scipy.stats import describe, skew, skewtest, kurtosis, kurtosistest
row = []
for para in t1a.colnames:
    irow = []
    if para == 'ID':
        irow=['min','max','med','mean','Std','S','K']
    elif para == 'Morph':
        irow=['-','-','-','-','-','-','-']
    elif para == 'DGMR':
        t1a_DGMR = t1a[para].data
        t1a_DGMR = t1a_DGMR[t1a_DGMR!=-1]
        nobs, minmax, mean, variance, Spara, Kpara = describe(t1a_DGMR)
        irow=[minmax[0],minmax[1], np.nanmedian(t1a[para].data), mean, variance**0.5, Spara, Kpara]
    else:
        nobs, minmax, mean, variance, Spara, Kpara = describe(t1a[para].data)
        irow=[minmax[0],minmax[1], np.nanmedian(t1a[para].data), mean, variance**0.5, Spara, Kpara]
    row.append(irow)
row = np.array(row)
row = row.T

# Statistics - part 2/2

t1a['ID'] = t1a['ID'].astype(str)
t1a['ID'].format = 's'
t1a['n_clumps'] = t1a['n_clumps'].astype(float)
t1a['n_clumps'].format = '.0f'

aaa = []
for i in range(len(t1a['DGMR'])):
    if t1a['DGMR'][i]==-1:
        aaa.append(' - ')
    else:
        aaa.append("{:.2f}".format(t1a['DGMR'][i]))
t1a.remove_column('DGMR')
aa = Column(aaa, name='DGMR')
t1a.add_column(aa,24)
for irow in row:
    t1a.add_row(irow)

if 1:
    t1a.write('tab/t1a.csv', format='csv', overwrite=True)
    t1a.write('tab/t1a.txt', format='ascii.fixed_width', overwrite=True)
    t1a.write('tab/t1a.tex', format='ascii.aastex', overwrite=True)


# In[6]:

from astropy.io import ascii

# Function to determine if l-v point is associated with Reid 2019 arm segments   
# To adjust accepted velocity and distance difference
dv = [5, 5]
dD = [999,1]
def in_Arm(lon, vel, dist, arm_l, arm_v, arm_D, dv=5, dD=1):
    '''
    Given (l,v) point, check if the point is within arms
    '''
    # interpreted vel from Reid arms
    vp = np.interp(lon, arm_l, arm_v)
    Dp = np.interp(lon, arm_l, arm_D)
    if abs(vel-vp) <= dv and abs(dist-Dp) <= dD:
        return True, abs(dist-Dp)
    else:
        return False, 1
arm_list = glob.glob('v2.4.1_bundle/*_lbvRBD.2019')

def in_Reid_Arms(lon, vel, dist,dv=5,dD=1):
    
    # in_arm flag indicator
    flag = False
    arm_fl_sep = 999
    in_which_arm = 'None'
    for seg in arm_list:
        cat = ascii.read(seg, comment='!')
        arm_l = cat['col1'].data
        arm_l[ arm_l > 280] -= 360.
        arm_b = cat['col2'].data
        arm_v = cat['col3'].data
        arm_D = cat['col6'].data
        
        flag = flag or in_Arm(lon, vel, dist, arm_l, arm_v, arm_D)[0]
        
        if in_Arm(lon, vel, dist, arm_l, arm_v, arm_D, dv, dD)[0]:
            if in_Arm(lon, vel, dist, arm_l, arm_v, arm_D)[1]<arm_fl_sep:
                in_which_arm=seg[14:17]
                arm_fl_sep=in_Arm(lon, vel, dist, arm_l, arm_v, arm_D)[1]
    return flag, in_which_arm
arm_name = []
arm_name_1kpc = []
for i in range(len(t)):
    flag_in, seg_in = in_Reid_Arms(t[i]['l_wt'],t[i]['v_wt'],t[i]['dkpc'],dv[0],dD[0])
    arm_name.append(seg_in)
    flag_in, seg_in = in_Reid_Arms(t[i]['l_wt'],t[i]['v_wt'],t[i]['dkpc'],dv[1],dD[1])   
    arm_name_1kpc.append(seg_in)
arm_name = np.array(arm_name)  
arm_name_1kpc = np.array(arm_name_1kpc)
len(arm_name[t['No']][arm_name[t['No']]!='None'])

f = open("fl&arm.txt",'w+')
for i in range(len(arm_name)):
    
    f.writelines([str(i), '\t', str(arm_name[i]), '\t', str(t['l_wt'][i]), '\t',str(t['b_wt'][i]), '\n'])    
f.close()

f = open("fl&arm_1kpc.txt",'w+')
for i in range(len(arm_name_1kpc)):
    
    f.writelines([str(i), '\t', str(arm_name_1kpc[i]), '\t', str(t['l_wt'][i]), '\t',str(t['b_wt'][i]), '\n'])  
f.close()

# l-v plot: Which arms are related ?

fp = open("fl&arm.txt")
arm_name = []
for linea in fp.readlines():
    arm_name.append(linea.split()[1])
arm_name = np.array(arm_name)
bone = np.array(t3['No'][arm_name[t3['No']]!='None'])

fp = open("fl&arm_1kpc.txt")
arm_name_1kpc = []
for linea in fp.readlines():
    arm_name_1kpc.append(linea.split()[1])
arm_name_1kpc = np.array(arm_name_1kpc)
bone_1kpc= np.array(t3['No'][arm_name_1kpc[t3['No']]!='None'])
close(4)
figure(4, figsize=(12,6))


def plot_arm(filename='v2.4.1_bundle/Out_lbvRBD.2019', color='r', alpha=.5):
    cat = ascii.read(filename, comment='!')
    arm_l = cat['col1'].data
    arm_l[ arm_l > 280] -= 360.
    arm_b = cat['col2'].data
    arm_v = cat['col3'].data

    
    plt.fill_between(arm_l, arm_v-5, arm_v+5, alpha=alpha, color=color, zorder=1)
    
    
plot_arm(filename='v2.4.1_bundle/N1N_lbvRBD.2019', color='r')
plot_arm(filename='v2.4.1_bundle/N1F_lbvRBD.2019', color='r')
plot_arm(filename='v2.4.1_bundle/N4N_lbvRBD.2019', color='r')
plot_arm(filename='v2.4.1_bundle/N4F_lbvRBD.2019', color='r')
plot_arm(filename='v2.4.1_bundle/ScN_lbvRBD.2019', color='y')
plot_arm(filename='v2.4.1_bundle/ScF_lbvRBD.2019', color='y')
plot_arm(filename='v2.4.1_bundle/SgN_lbvRBD.2019', color='b')
plot_arm(filename='v2.4.1_bundle/SgF_lbvRBD.2019', color='b')
plot_arm(filename='v2.4.1_bundle/CrN_lbvRBD.2019', color='darkblue')
plot_arm(filename='v2.4.1_bundle/CrF_lbvRBD.2019', color='darkblue')
plot_arm(filename='v2.4.1_bundle/Loc_lbvRBD.2019', color='c')
plot_arm(filename='v2.4.1_bundle/Per_lbvRBD.2019', color='m')
plot_arm(filename='v2.4.1_bundle/Out_lbvRBD.2019', color='salmon')
plot_arm(filename='v2.4.1_bundle/OSC_lbvRBD.2019', color='yellow')
plot_arm(filename='v2.4.1_bundle/CtF_lbvRBD.2019', color='gold')
plot_arm(filename='v2.4.1_bundle/CtN_lbvRBD.2019', color='gold')
plot_arm(filename='v2.4.1_bundle/3kN_lbvRBD.2019', color='darkorange')
plot_arm(filename='v2.4.1_bundle/3kF_lbvRBD.2019', color='darkorange')

plot_arm(filename='v2.4.1_bundle/CnN_lbvRBD.2019', color='silver')
plot_arm(filename='v2.4.1_bundle/CnX_lbvRBD.2019', color='silver')
plot_arm(filename='v2.4.1_bundle/LoS_lbvRBD.2019', color='silver')
plot_arm(filename='v2.4.1_bundle/AqS_lbvRBD.2019', color='silver')
plot_arm(filename='v2.4.1_bundle/AqR_lbvRBD.2019', color='silver')
plot_arm(filename='v2.4.1_bundle/ScS_lbvRBD.2019', color='silver')

plt.scatter(t1['l_wt'], t1['v_wt'], s=100, alpha=.8, facecolor='none', edgecolor='k', lw=2, label='Filaments',zorder=2)
plt.scatter(t[bone]['l_wt'], t[bone]['v_wt'], s=80, alpha=1, color='r', marker='x', lw=2, label='Bones',zorder=2)
xlim(70, -70)
ylim(-150, 150)

text(-35, -90, 'Norma', fontsize='x-large')
text(38, 120, 'Scutum', fontsize='x-large')
text(69, 75, 'Sagittarius', fontsize='x-large')
text(58, 0, 'Perseus', fontsize='x-large')
text(55, -50, 'Outer', fontsize='x-large')
text(50, -100, 'OSC', fontsize='x-large')
text(10, 100, '3-kpc', fontsize='x-large')
text(-30, 50, 'Carina', fontsize='x-large')
text(-35, 10, 'Centaurus', fontsize='x-large')



def fill_range(ends=[5, 60]):
    fill_between(ends, [-150,-150], [-140,-140], color='grey', alpha=1, zorder=-1)
for rg in [[5, 60], [-60, -5]]:
    fill_range(rg)
legend(loc='upper right',
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize='xx-large')

xlabel("Galactic Longitude (deg)", fontsize="xx-large")
ylabel("LSR Velocity (km/s)", fontsize="xx-large")
plt.tick_params(labelsize='x-large')
plt.minorticks_on()
plt.tight_layout()

if not os.path.isdir('fig'):
    os.makedirs('fig')
if 1:
    plt.savefig("fig/arm.png")
    plt.savefig("fig/arm.eps")
    plt.savefig("fig/arm.pdf")

# l-d plot
close(4)
figure(4, figsize=(12,6))
def plot_arm(filename='v2.4.1_bundle/Out_lbvRBD.2019', color='r', alpha=.5):
    cat = ascii.read(filename, comment='!')
    arm_l = cat['col1'].data
    arm_l[ arm_l > 280] -= 360.
    arm_b = cat['col2'].data
    arm_D = cat['col6'].data
    plt.fill_between(arm_l, arm_D-0.5, arm_D+0.5, alpha=alpha, color=color, zorder=1)  

plot_arm(filename='v2.4.1_bundle/N1N_lbvRBD.2019', color='r')
plot_arm(filename='v2.4.1_bundle/N1F_lbvRBD.2019', color='r')
plot_arm(filename='v2.4.1_bundle/N4N_lbvRBD.2019', color='r')
plot_arm(filename='v2.4.1_bundle/N4F_lbvRBD.2019', color='r')
plot_arm(filename='v2.4.1_bundle/ScN_lbvRBD.2019', color='y')
plot_arm(filename='v2.4.1_bundle/ScF_lbvRBD.2019', color='y')
plot_arm(filename='v2.4.1_bundle/SgN_lbvRBD.2019', color='b')
plot_arm(filename='v2.4.1_bundle/SgF_lbvRBD.2019', color='b')
plot_arm(filename='v2.4.1_bundle/CrN_lbvRBD.2019', color='darkblue')
plot_arm(filename='v2.4.1_bundle/CrF_lbvRBD.2019', color='darkblue')
plot_arm(filename='v2.4.1_bundle/Loc_lbvRBD.2019', color='c')
plot_arm(filename='v2.4.1_bundle/Per_lbvRBD.2019', color='m')
plot_arm(filename='v2.4.1_bundle/Out_lbvRBD.2019', color='salmon')
plot_arm(filename='v2.4.1_bundle/OSC_lbvRBD.2019', color='yellow')
plot_arm(filename='v2.4.1_bundle/CtF_lbvRBD.2019', color='gold')
plot_arm(filename='v2.4.1_bundle/CtN_lbvRBD.2019', color='gold')
plot_arm(filename='v2.4.1_bundle/3kN_lbvRBD.2019', color='darkorange')
plot_arm(filename='v2.4.1_bundle/3kF_lbvRBD.2019', color='darkorange')

plot_arm(filename='v2.4.1_bundle/CnN_lbvRBD.2019', color='silver')
plot_arm(filename='v2.4.1_bundle/CnX_lbvRBD.2019', color='silver')
plot_arm(filename='v2.4.1_bundle/LoS_lbvRBD.2019', color='silver')
plot_arm(filename='v2.4.1_bundle/AqS_lbvRBD.2019', color='silver')
plot_arm(filename='v2.4.1_bundle/AqR_lbvRBD.2019', color='silver')
plot_arm(filename='v2.4.1_bundle/ScS_lbvRBD.2019', color='silver')


plt.scatter(t1['l_wt'], t1['dkpc'], s=100, alpha=.8, facecolor='none', edgecolor='k', lw=2, label='Filaments',zorder=2)
plt.scatter(t[bone]['l_wt'], t[bone]['dkpc'], s=80, alpha=1, color='r', marker='x', lw=2, label='Bones',zorder=2)
plt.scatter(t[bone_1kpc]['l_wt'], t[bone_1kpc]['dkpc'], s=80, alpha=1, color='b', marker='+', lw=2, label='Bones with distance constraint',zorder=2)
xlim(70, -70)
ylim(-3, 25)

def fill_range(ends=[5, 60]):
    fill_between(ends, [-3,-3], [-2,-2], color='grey', alpha=1, zorder=-1)
for rg in [[5, 60], [-60, -5]]:
    fill_range(rg)
    

legend(loc='upper left', 
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize='x-large')
xlabel("Galactic Longitude (deg)", fontsize="x-large")
ylabel("Distance from the sun (kpc)", fontsize="x-large")
plt.tick_params(labelsize='x-large')
plt.minorticks_on()
plt.tight_layout()

if 1:
    plt.savefig("fig/arm_lD.png")
    plt.savefig("fig/arm_lD.eps")
    plt.savefig("fig/arm_lD.pdf")

# Bird's view - face-on

fp = open("fl&arm.txt")
arm_name = []
for linea in fp.readlines():
    arm_name.append(linea.split()[1])
arm_name = np.array(arm_name)
bone = np.array(t3['No'][arm_name[t3['No']]!='None'])

fp = open("fl&arm_1kpc.txt")
arm_name_1kpc = []
for linea in fp.readlines():
    arm_name_1kpc.append(linea.split()[1])
arm_name_1kpc = np.array(arm_name_1kpc)
bone_1kpc= np.array(t3['No'][arm_name_1kpc[t3['No']]!='None'])

t3a=t[bone]
t3b=t[bone_1kpc]

rez=600 # dpi
wid=9.25 # Must be proportional to x and y limits below
hei=12.5

close(4)
fig = plt.figure(4, figsize=(wid, hei))
sp = fig.add_subplot(111)

sp.set_xlim([-15, 15])
sp.set_ylim([-15, 20])
plt.axes().set_aspect('equal')
# line is in points: 72 points per inch
point_hei=hei*72 
x1,x2,y1,y2 = plt.axis()
yrange = y2 - y1

linewid = 1.0 #np.array([.1, .2, .3, .4, .5, .6])    # in data units
# For the calculation below, you have to adjust width by 0.8
# because the top and bottom 10% of the figure are labels & axis
pointlinewid = (linewid * (point_hei/yrange)) * 0.8  # corresponding width in pts


def plot_arm(filename='v2.4.1_bundle/Out_lbvRBD.2019', arm_width=0.63, color='r'):
    cat = ascii.read(filename, comment='!')
    arm_l = cat['col1'].data
    arm_l[ arm_l > 280] -= 360.
    arm_b = cat['col2'].data
    arm_v = cat['col3'].data
    
    arm_R = cat['col4'].data
    arm_B = cat['col5'].data
    arm_D = cat['col6'].data

    X = arm_D*np.sin( deg2rad(arm_l) )
    Y = 8.34 - arm_D*np.cos( deg2rad(arm_l) )
    
    plt.plot(X, Y, linewidth=pointlinewid*arm_width, color=color, alpha=.5, zorder=1)

plot_arm(filename='v2.4.1_bundle/N1N_lbvRBD.2019', color='r', arm_width=0.14)
plot_arm(filename='v2.4.1_bundle/N1F_lbvRBD.2019', color='r', arm_width=0.14)
plot_arm(filename='v2.4.1_bundle/N4N_lbvRBD.2019', color='r', arm_width=0.14)
plot_arm(filename='v2.4.1_bundle/N4F_lbvRBD.2019', color='r', arm_width=0.14)
plot_arm(filename='v2.4.1_bundle/ScN_lbvRBD.2019', color='y', arm_width=0.23)
plot_arm(filename='v2.4.1_bundle/ScF_lbvRBD.2019', color='y', arm_width=0.23)
plot_arm(filename='v2.4.1_bundle/SgN_lbvRBD.2019', color='b', arm_width=0.27)
plot_arm(filename='v2.4.1_bundle/SgF_lbvRBD.2019', color='b', arm_width=0.27)
plot_arm(filename='v2.4.1_bundle/CrN_lbvRBD.2019', color='darkblue', arm_width=0.27)
plot_arm(filename='v2.4.1_bundle/CrF_lbvRBD.2019', color='darkblue', arm_width=0.27)
plot_arm(filename='v2.4.1_bundle/Loc_lbvRBD.2019', color='c', arm_width=0.31)
plot_arm(filename='v2.4.1_bundle/Per_lbvRBD.2019', color='m', arm_width=0.35)
plot_arm(filename='v2.4.1_bundle/Out_lbvRBD.2019', color='salmon', arm_width=0.65)
plot_arm(filename='v2.4.1_bundle/OSC_lbvRBD.2019', color='yellow', arm_width=0.23)
plot_arm(filename='v2.4.1_bundle/CtF_lbvRBD.2019', color='gold', arm_width=0.23)
plot_arm(filename='v2.4.1_bundle/CtN_lbvRBD.2019', color='gold', arm_width=0.23)
plot_arm(filename='v2.4.1_bundle/3kN_lbvRBD.2019', color='darkorange', arm_width=0.18)
plot_arm(filename='v2.4.1_bundle/3kF_lbvRBD.2019', color='darkorange', arm_width=0.18)

plot_arm(filename='v2.4.1_bundle/CnN_lbvRBD.2019', color='silver', arm_width=0.38)
plot_arm(filename='v2.4.1_bundle/CnX_lbvRBD.2019', color='silver', arm_width=0.38)
plot_arm(filename='v2.4.1_bundle/LoS_lbvRBD.2019', color='silver', arm_width=0.38)
plot_arm(filename='v2.4.1_bundle/AqS_lbvRBD.2019', color='silver', arm_width=0.38)
plot_arm(filename='v2.4.1_bundle/AqR_lbvRBD.2019', color='silver', arm_width=0.38)
plot_arm(filename='v2.4.1_bundle/ScS_lbvRBD.2019', color='silver', arm_width=0.38)

# plot clumps
X = a_origin['distance'] * np.sin( deg2rad(l) )
Y = 8.34 - a_origin['distance'] * np.cos( deg2rad(l) )
X = distance * np.sin( deg2rad(l) )
Y = 8.34 - distance * np.cos( deg2rad(l) )
plt.scatter(X, Y, s=10, alpha=0.8, edgecolor='none', marker='.', color='darkred')

# plot Filaments
X = t1['dkpc'] * np.sin( deg2rad(t1['l_wt']) )
Y = 8.34 - t1['dkpc'] * np.cos( deg2rad(t1['l_wt']) )
plt.scatter(X, Y, s=100, alpha=.8, facecolor='none', edgecolor='k', lw=2, label='Filaments',zorder=2)

# plot Bones
X = t[bone]['dkpc'] * np.sin( deg2rad(t[bone]['l_wt']) )
Y = 8.34 - t[bone]['dkpc'] * np.cos( deg2rad(t[bone]['l_wt']) )
plt.scatter(X, Y,  s=80, alpha=1, color='r', marker='x', lw=2, label='Bones', zorder=2)

# plot Bones within 1kpc
X = t[bone_1kpc]['dkpc'] * np.sin( deg2rad(t[bone_1kpc]['l_wt']) )
Y = 8.34 - t[bone_1kpc]['dkpc'] * np.cos( deg2rad(t[bone_1kpc]['l_wt']) )
plt.scatter(X, Y,  s=80, alpha=1, color='b', marker='+', lw=2, label='Bones with distance constraint', zorder=2)



# Sun, GC
scatter(0, 0, marker='+', s=300, color='k')
scatter(0, 8.34, marker='.', color='k')
scatter(0, 8.34, s=160, marker='o', facecolor='None', edgecolor='k')


text(0.2, 0, 'GC', fontsize='x-large')
text(-0.5, 8.5, 'Sun', fontsize='x-large')

text(-3.3, 8.8, 'Local', fontsize='x-large')
text(-3.3, 3.1, '', fontsize='x-large')
text(-1, -3.8, 'Sagittarius', fontsize='x-large')
text(2.5, -0.5, 'Scutum', fontsize='x-large')
text(-3, -5.5, 'Norma', fontsize='x-large')
text(-3, 10.5, 'Perseus', fontsize='x-large')
text(-3, 12.5, 'Outer', fontsize='x-large')
text(8, 15, 'OSC', fontsize='x-large')
text(-4, -8, 'Centaurus', fontsize='x-large')
text(-9, -10, 'Carina', fontsize='x-large')
text(-0.5, -2.5, '3-kpc', fontsize='x-large')

legend(loc='upper right', 
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize='x-large')

xlabel("X (kpc)", fontsize="x-large")
ylabel("Y (kpc)", fontsize="x-large")
plt.tick_params(labelsize='x-large')
plt.minorticks_on()

plt.tight_layout()

if 1:
    plt.savefig('fig/faceon.png',dpi=rez)
    plt.savefig('fig/faceon.eps',dpi=rez)
    plt.savefig('fig/faceon.pdf',dpi=rez)


# In[7]:

if not os.path.isdir('fig'):
    os.makedirs('fig')
# Make histograms l
plt.rcParams['xtick.direction'] = 'in'  
plt.rcParams['ytick.direction'] = 'in' 
close(3)
figure(3,dpi=100)
# only to determin bins
n, bins, patches = hist([t1['l_wt']], bins=20, 
     normed=True, histtype='bar', alpha=0.1, color='blue')
# now plot
hist([t1['l_wt']], label=['Filaments'], bins=bins,
    normed=True, histtype='bar', alpha=0.6, color='blue')

hist(l, label=['ATLASGAL sources'], bins=bins, 
     normed=True, histtype='step', alpha=0.9, color='r', lw=3)

xlabel(r"$l$, Galactic Longitude (deg)", fontsize="xx-large")
ylabel(r"$N/(N_{\rm total} \times \Delta \rm{bin})$, Probability Density", fontsize="large")
plt.tick_params(labelsize='x-large')

# Put a legend to the right of the current axis
legend(loc='upper right', #bbox_to_anchor=(1, 0.5), 
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize='smaller')
plt.tight_layout()
if 1:
    plt.savefig("fig/a-hist_l.png")
    plt.savefig("fig/a-hist_l.eps")
    plt.savefig("fig/a-hist_l.pdf")

    
# Make histograms l
plt.rcParams['xtick.direction'] = 'in'  
plt.rcParams['ytick.direction'] = 'in' 
close(3)
figure(3,dpi=100)
# only to determin bins
n, bins, patches = hist([t1['b_wt']], bins=20, 
     normed=True, histtype='bar', alpha=0.1, color='blue')
# now plot
hist([t1['b_wt']], label=['Filaments'], bins=bins,
    normed=True, histtype='bar', alpha=0.6, color='blue')

hist(b, label=['ATLASGAL sources'], bins=bins, 
     normed=True, histtype='step', alpha=0.9, color='r', lw=3)

xlabel(r"$l$, Galactic Latitude (deg)", fontsize="xx-large")
ylabel(r"$N/(N_{\rm total} \times \Delta \rm{bin})$, Probability Density", fontsize="large")
plt.tick_params(labelsize='x-large')

# Put a legend to the right of the current axis
legend(loc='upper right', #bbox_to_anchor=(1, 0.5), 
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize='smaller')
plt.tight_layout()
if 1:
    plt.savefig("fig/b-hist_b.png")
    plt.savefig("fig/b-hist_b.eps")
    plt.savefig("fig/b-hist_b.pdf")

# Make histograms z
    
close(3)
figure(3,dpi=100)
# only to determine bins
n, bins, patches = hist(t1['z'], label=['Filaments'], bins=20,
     normed=True, histtype='bar', alpha=0.6, color='blue')
exec(open("sgraframe.py").read())
z = scale_height(l, b, distance)
n, bins, patches = hist(z[~np.isnan(z)], label=['ATLASGAL sources'], bins=bins,
     normed=True, histtype='step', alpha=1, color='r', lw=3)
xlabel("$z$, Height to Galactic mid-plane (pc)", fontsize="xx-large")
ylabel(r"$N/(N_{\rm total} \times \Delta \rm{bin})$, Probability Density", fontsize="large")
plt.tick_params(labelsize='xx-large')
legend(loc='upper right', 
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize="smaller")
plt.tight_layout()
plt.savefig("fig/c-hist_z.png")
plt.savefig("fig/c-hist_z.eps")
plt.savefig("fig/c-hist_z.pdf")


# Make histograms Rgc
    
close(3)
figure(3,dpi=100)
n, bins, patches = hist(t1['Rgc'], label=['Filaments'], bins=15,
     normed=True, histtype='bar', alpha=0.6, color='blue')
n, bins, patches = hist(Rgcc, label=['ATLASGAL sources'], bins=bins,
     normed=True, histtype='step', alpha=1, color='r', lw=3)
xlabel(r"$R_{\rm gc}$, Galactocentric Radius (kpc)", fontsize="xx-large")
ylabel(r"$N/(N_{\rm total} \times \Delta \rm{bin})$, Probability Density", fontsize="large")
plt.tick_params(labelsize='xx-large')
legend(loc='upper right', #bbox_to_anchor=(1, 0.5), 
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize='smaller')
plt.tight_layout()
plt.savefig("fig/d-hist_Rgc.png")
plt.savefig("fig/d-hist_Rgc.eps")
plt.savefig("fig/d-hist_Rgc.pdf")


# Make histograms distance
    
close(3)
figure(3,dpi=100)
n, bins, patches = hist(t1['dkpc'], label=['Filaments'], bins=15,
     normed=True, histtype='bar', alpha=0.6, color='blue')
n, bins, patches = hist(distance[~np.isnan(distance)], label=['ATLASGAL sources'], bins=bins,
     normed=True, histtype='step', alpha=1, color='r', lw=3)
xlabel(r"distance (kpc)", fontsize="xx-large")
ylabel(r"$N/(N_{\rm total} \times \Delta \rm{bin})$, Probability Density", fontsize="large")
plt.tick_params(labelsize='xx-large')
legend(loc='upper right', 
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize='smaller')
plt.tight_layout()
if 1:
    plt.savefig("fig/e-hist_dkpc.png")
    plt.savefig("fig/e-hist_dkpc.eps")
    plt.savefig("fig/e-hist_dkpc.pdf")

# Make histograms velocity

close(3)
figure(3,dpi=100)

n, bins, patches = hist(t1['v_wt'], label=['Filaments'], bins=15,
     normed=True, histtype='bar', alpha=0.6, color='blue')
n, bins, patches = hist(v, label=['ATLASGAL sources'], bins=bins,
     normed=True, histtype='step', alpha=1, color='r', lw=3)
xlabel(r"radial velocity (km/s)", fontsize="xx-large")
ylabel(r"$N/(N_{\rm total} \times \Delta \rm{bin})$, Probability Density", fontsize="large")
plt.tick_params(labelsize='xx-large')
legend(loc='upper right', 
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize='smaller')
plt.tight_layout()

plt.savefig("fig/f-hist_v.png")
plt.savefig("fig/f-hist_v.eps")
plt.savefig("fig/f-hist_v.pdf")


# Make histograms Mass
    
close(3)
figure(3,dpi=200)
n, bins, patches = hist(np.log10(t1['mass']*1000), label=['Filaments'], bins=20,
     normed=False, histtype='bar', alpha=0.6, color='blue')
hist(np.log10(t3a['mass']*1000), label=['bones'], bins=bins,
     normed=False, histtype='bar', alpha=.6, color='r', lw=2)
hist(np.log10(t3b['mass']*1000), label=['bones with\ndistance constraint'], bins=bins,
     normed=False, histtype='bar', alpha=.6, color='black', lw=2)

xlabel(r"Mass (${\rm log} M/M_\odot$)", fontsize="xx-large")
ylabel(r"Number", fontsize="xx-large")
plt.tick_params(labelsize='xx-large')
legend(loc='upper right', 
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize='medium')
plt.xlim(2.8,6.4)
plt.grid()
plt.tight_layout()
if 1:
    plt.savefig("fig/g-hist_M.png")
    plt.savefig("fig/g-hist_M.eps")
    plt.savefig("fig/g-hist_M.pdf")

# Make histograms Length
    
close(3)
figure(3,dpi=200)

n, bins, patches = hist([t1['fl_length']], label=['Filaments'], bins=20, 
                        normed=False, histtype='bar', alpha=0.6, color='blue')
hist(t3a['fl_length'], label=['Bones'], bins=bins,
     normed=False, histtype='bar', alpha=0.6, color='r')
hist(t3b['fl_length'], label=['Bones with\ndistance constraint'], bins=bins,
     normed=False, histtype='bar', alpha=0.6, color='black')

xlabel(r"Length (pc)", fontsize="xx-large")
ylabel(r"Number", fontsize="xx-large")
plt.tick_params(labelsize='xx-large')

legend(loc='upper right', 
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize='smaller')
plt.grid()
plt.tight_layout()
if 1:
    plt.savefig("fig/i-hist_len.png")
    plt.savefig("fig/i-hist_len.eps")
    plt.savefig("fig/i-hist_len.pdf")

# Make histograms Length deg
    
close(3)
figure(3,dpi=200)

n, bins, patches = hist([t1['fl_len_deg']], label=['Filaments'], bins=20, 
     normed=False, histtype='bar', alpha=0.6, color='blue')
hist(t3a['fl_len_deg'], label=['Bones'], bins=bins,
     normed=False, histtype='bar', alpha=0.6, color='r')
hist(t3b['fl_len_deg'], label=['Bones with\ndistance constraint'], bins=bins,
     normed=False, histtype='bar', alpha=0.6, color='black')
xlabel(r"Length (deg)", fontsize="xx-large")
ylabel(r"Number", fontsize="xx-large")
plt.tick_params(labelsize='xx-large')

legend(loc='upper right', 
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize='smaller')
plt.grid()
plt.tight_layout()

plt.savefig("fig/j-hist_len_deg.png")
plt.savefig("fig/j-hist_len_deg.eps")
plt.savefig("fig/j-hist_len_deg.pdf")   


# Make histograms line Mass
    
close(3)
figure(3,dpi=200)
n, bins, patches = hist(np.log10(t1['M_L']), label=['Filaments'], bins=20,
     normed=False, histtype='bar', alpha=0.6, color='blue')
hist(np.log10(t3a['M_L']), label=['Bones'], bins=bins,
     normed=False, histtype='bar', alpha=0.6, color='r')
hist(np.log10(t3b['M_L']), label=['Bones with\ndistance constraint'], bins=bins,
     normed=False, histtype='bar', alpha=0.6, color='black')
xlabel(r"Line mass (${\rm log} (M/M_\odot)\cdot(l/pc)^{-1}$)", fontsize="xx-large")
ylabel(r"Number", fontsize="xx-large")
plt.tick_params(labelsize='xx-large')
legend(loc='upper right',
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize='smaller')
plt.grid()
plt.tight_layout()
if 1:
    plt.savefig("fig/k-hist_M_L.png")
    plt.savefig("fig/k-hist_M_L.eps")
    plt.savefig("fig/k-hist_M_L.pdf")

# Make histograms theta
    
close(3)
figure(3,dpi=200)

n, bins, patches = hist(t1['theta'], label=['Filaments'], bins=20,
     normed=False, histtype='bar', alpha=0.6, color='blue')
hist(t3a['theta'], label=['Bones'], bins=bins,
     normed=False, histtype='bar', alpha=0.6, color='r')
hist(t3b['theta'], label=['Bones with\ndistance constraint'], bins=bins,
     normed=False, histtype='bar', alpha=0.6, color='black')
xlabel(r"$\theta$, Orientation w.r.t. Galactic mid-plane (deg)", fontsize="xx-large")
ylabel(r"Number", fontsize="xx-large")
plt.tick_params(labelsize='xx-large')
plt.ylim(0,17.5)
legend(loc='upper right', 
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize="smaller")
plt.grid()
plt.tight_layout()
plt.savefig("fig/l-hist_theta.png")
plt.savefig("fig/l-hist_theta.eps")
plt.savefig("fig/l-hist_theta.pdf")

# Make histograms Tmin
close(3)
figure(3,dpi=200)

n, bins, patches = hist(t1['T_min'], label=['Filaments'], bins=20,
     normed=False, histtype='bar', alpha=0.6, color='blue')
hist(t3a['T_min'], label=['Bones'], bins=bins,
     normed=False, histtype='bar', alpha=0.6, color='r')
hist(t3b['T_min'], label=['Bones with\ndistance constraint'], bins=bins,
     normed=False, histtype='bar', alpha=0.6, color='black')
xlabel(r"$T_{\rm min} (K)$", fontsize="xx-large")
ylabel(r"Number", fontsize="xx-large")
plt.tick_params(labelsize='xx-large')
legend(loc='upper right',
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize="smaller")
plt.grid()
plt.tight_layout()
plt.savefig("fig/m-hist_Tmin.png")
plt.savefig("fig/m-hist_Tmin.eps")
plt.savefig("fig/m-hist_Tmin.pdf")


# Make histograms Tmax
close(3)
figure(3,dpi=200)

n, bins, patches = hist(t1['T_max'], label=['Filaments'], bins=20,
     normed=False, histtype='bar', alpha=0.6, color='blue')
hist(t3a['T_max'], label=['Bones'], bins=bins,
     normed=False, histtype='bar', alpha=0.6, color='r')
hist(t3b['T_max'], label=['Bones with\ndistance constraint'], bins=bins,
     normed=False, histtype='bar', alpha=0.6, color='black')
xlabel(r"$T_{\rm max} (K)$", fontsize="xx-large")
ylabel(r"Number", fontsize="xx-large")
plt.tick_params(labelsize='xx-large')

legend(loc='upper right', 
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize="smaller")
plt.grid()
plt.tight_layout()
plt.savefig("fig/n-hist_Tmax.png")
plt.savefig("fig/n-hist_Tmax.eps")
plt.savefig("fig/n-hist_Tmax.pdf")


# Make histograms colH2
close(3)
figure(3,dpi=100)

n, bins, patches = hist(t1['colH2'], label=['Filaments'], bins=20,
     normed=False, histtype='bar', alpha=0.6, color='blue')
hist(t3a['colH2'], label=['Bones'], bins=bins,
     normed=False, histtype='bar', alpha=0.6, color='r')
hist(t3b['colH2'], label=['Bones with\ndistance constraint'], bins=bins,
     normed=False, histtype='bar', alpha=0.6, color='black')
xlabel(r"$H_2\ column\ density/10^{\rm 22}cm^{\rm -2}$", fontsize="xx-large")
ylabel(r"Number", fontsize="xx-large")
plt.tick_params(labelsize='xx-large')
legend(loc='upper right',
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize="small")
plt.grid()
plt.tight_layout()
plt.savefig("fig/o-hist_colH2.png")
plt.savefig("fig/o-hist_colH2.eps")
plt.savefig("fig/o-hist_colH2.pdf")

# Make histograms volH2
close(3)
figure(3,dpi=100)
n, bins, patches = hist(t1['volH2'], label=['Filaments'], bins=20,
     normed=False, histtype='bar', alpha=0.6, color='blue')
hist(t3a['volH2'], label=['Bones'], bins=bins,
     normed=False, histtype='bar', alpha=0.6, color='r')
hist(t3b['volH2'], label=['Bones with\ndistance constraint'], bins=bins,
     normed=False, histtype='bar', alpha=0.6, color='black')
xlabel(r"$H_2\ volume\  density/10^3cm^{\rm -3}$", fontsize="xx-large")
ylabel(r"Number", fontsize="xx-large")
plt.tick_params(labelsize='xx-large')
legend(loc='upper right',
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize="large")
plt.grid()
plt.tight_layout()
plt.savefig("fig/p-hist_volH2.png")
plt.savefig("fig/p-hist_volH2.eps")
plt.savefig("fig/p-hist_volH2.pdf")

# Make histograms non-thermal velocity dispersion
close(3)
figure(3,dpi=100)

n, bins, patches = hist(t1['CVD'], label=['Filaments'], bins=20,
     normed=False, histtype='bar', alpha=0.6, color='blue')
hist(t3a['CVD'], label=['Bones'], bins=bins,
     normed=False, histtype='bar', alpha=0.6, color='r')
hist(t3b['CVD'], label=['Bones with\ndistance constraint'], bins=bins,
     normed=False, histtype='bar', alpha=0.6, color='black')
xlabel(r"$velocity\ dispersion\ (km\ s^{\rm -1})$", fontsize="xx-large")
ylabel(r"Number", fontsize="xx-large")
plt.tick_params(labelsize='xx-large')
legend(loc='upper right',
          scatterpoints=1,ncol=1,fancybox=True,shadow=True, fontsize="smaller")
plt.grid()
plt.tight_layout()
if 1:
    plt.savefig("fig/q-hist_CVD.png")
    plt.savefig("fig/q-hist_CVD.eps")
    plt.savefig("fig/q-hist_CVD.pdf")

